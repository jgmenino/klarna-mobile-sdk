//
//  KlarnaMobileSDK.h
//  KlarnaMobileSDK
//
//  Created by Carlos Jimenez on 2020-01-27.
//  Copyright © 2020 Klarna Bank AB. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KlarnaMobileSDK
FOUNDATION_EXPORT double KlarnaMobileSDKVersionNumber;

//! Project version string for KlarnaMobileSDK
FOUNDATION_EXPORT const unsigned char KlarnaMobileSDKVersionString[];
